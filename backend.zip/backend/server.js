const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();

app.use(cors());
app.use(bodyParser.json());

app.post('/monitor', (req, res) => {
  const { url } = req.body;
  console.log(`Monitoring URL: ${url}`);
  res.json({ message: `Monitoring started for: ${url}` });
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Backend is running on http://localhost:${PORT}`);
});
